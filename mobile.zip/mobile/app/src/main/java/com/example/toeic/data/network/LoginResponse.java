package com.example.toeic.data.network;

public class LoginResponse {
    public String accessToken;
}
