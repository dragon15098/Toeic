package com.example.toeic.feature.exam.exam_list;

import com.example.base.BaseView;

public interface ExamView extends BaseView {
    void notifyView();
}
