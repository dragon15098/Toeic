package com.example.toeic.feature.exam.test;

import com.example.base.BaseView;

public interface TestView extends BaseView {
}
