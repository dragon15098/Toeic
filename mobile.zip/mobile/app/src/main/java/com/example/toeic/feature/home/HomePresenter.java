package com.example.toeic.feature.home;

import com.example.base.BasePresenter;

interface HomePresenter extends BasePresenter {

}