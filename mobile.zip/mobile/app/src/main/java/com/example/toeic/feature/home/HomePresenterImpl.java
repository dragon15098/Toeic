package com.example.toeic.feature.home;

import com.example.base.BasePresenterImpl;

public class HomePresenterImpl extends BasePresenterImpl implements HomePresenter {
}
