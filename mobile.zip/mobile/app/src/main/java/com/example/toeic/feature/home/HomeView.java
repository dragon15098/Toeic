package com.example.toeic.feature.home;

import com.example.base.BaseView;

public interface HomeView extends BaseView {
}

