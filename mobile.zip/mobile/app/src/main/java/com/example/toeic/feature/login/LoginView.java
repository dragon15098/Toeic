package com.example.toeic.feature.login;

import com.example.base.BaseActivity;
import com.example.base.BasePresenter;
import com.example.base.BasePresenterImpl;
import com.example.base.BaseView;

interface LoginView extends BaseView {
    void loginSuccess();
}

