package com.example.toeic.feature.practice.part;

public interface PartView {
    void notifyRecycleView();
}
