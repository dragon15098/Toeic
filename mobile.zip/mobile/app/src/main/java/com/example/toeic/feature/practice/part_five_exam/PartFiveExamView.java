package com.example.toeic.feature.practice.part_five_exam;

import com.example.toeic.feature.practice.part_exam.question.PartQuestionExamView;

public interface PartFiveExamView extends PartQuestionExamView {
}
