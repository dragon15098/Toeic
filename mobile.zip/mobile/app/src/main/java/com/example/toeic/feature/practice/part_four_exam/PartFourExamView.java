package com.example.toeic.feature.practice.part_four_exam;

import com.example.toeic.feature.practice.part_exam.group_question.PartGroupQuestionExamView;

public interface PartFourExamView extends PartGroupQuestionExamView {
}
