package com.example.toeic.feature.practice.part_list;

import com.example.base.BasePresenter;

interface PartListPresenter extends BasePresenter {
}
