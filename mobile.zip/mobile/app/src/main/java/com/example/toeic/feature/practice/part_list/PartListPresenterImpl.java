package com.example.toeic.feature.practice.part_list;

import com.example.base.BasePresenterImpl;

public class PartListPresenterImpl extends BasePresenterImpl implements PartListPresenter {
}
