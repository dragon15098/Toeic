package com.example.toeic.feature.practice.part_list;

import com.example.base.BaseView;

public interface PartListView extends BaseView {
}
