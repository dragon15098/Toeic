package com.example.toeic.feature.practice.part_main;

import com.example.base.BasePresenter;

public interface PartMainPresent extends BasePresenter {
}
