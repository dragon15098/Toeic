package com.example.toeic.feature.practice.part_main;

import com.example.base.BasePresenterImpl;

public class PartMainPresentImpl extends BasePresenterImpl implements PartMainPresent {
}
