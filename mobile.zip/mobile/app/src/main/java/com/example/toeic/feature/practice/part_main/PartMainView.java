package com.example.toeic.feature.practice.part_main;

import com.example.base.BaseView;

public interface PartMainView extends BaseView {
}
