package com.example.toeic.feature.practice.part_one_exam;

import com.example.toeic.feature.practice.part_exam.question.PartQuestionExamView;

public interface PartOneExamView extends PartQuestionExamView {

}
