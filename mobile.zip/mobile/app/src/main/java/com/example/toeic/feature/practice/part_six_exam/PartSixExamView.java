package com.example.toeic.feature.practice.part_six_exam;

import com.example.toeic.feature.practice.part_exam.group_question.PartGroupQuestionExamView;

public interface PartSixExamView extends PartGroupQuestionExamView {

}
