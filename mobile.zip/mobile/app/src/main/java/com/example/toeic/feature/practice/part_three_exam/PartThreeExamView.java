package com.example.toeic.feature.practice.part_three_exam;

import com.example.toeic.feature.practice.part_exam.group_question.PartGroupQuestionExamView;

public interface PartThreeExamView extends PartGroupQuestionExamView {
}
