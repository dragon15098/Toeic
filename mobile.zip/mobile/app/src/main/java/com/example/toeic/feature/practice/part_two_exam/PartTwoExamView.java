package com.example.toeic.feature.practice.part_two_exam;

import com.example.toeic.feature.practice.part_exam.question.PartQuestionExamView;

public interface PartTwoExamView extends PartQuestionExamView {
}
