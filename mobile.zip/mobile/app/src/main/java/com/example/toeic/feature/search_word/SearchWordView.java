package com.example.toeic.feature.search_word;

import com.example.base.BaseView;

public interface SearchWordView extends BaseView {
    void notifyDisplay();
}
