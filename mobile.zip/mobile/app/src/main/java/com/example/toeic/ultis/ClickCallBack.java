package com.example.toeic.ultis;

import android.view.View;

public interface ClickCallBack {
    void onClickEvent(View view, Object object);
}
