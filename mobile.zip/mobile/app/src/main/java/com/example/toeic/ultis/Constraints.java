package com.example.toeic.ultis;

public class Constraints {
    private Constraints() {

    }


    public static String EXAM = "EXAM";
    public static String PART = "PART";
    public static String RESULT = "RESULT";
    public static String EMPTY_STRING = "";
}
