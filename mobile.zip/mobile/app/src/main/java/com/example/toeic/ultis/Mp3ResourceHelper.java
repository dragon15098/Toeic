package com.example.toeic.ultis;

public class Mp3ResourceHelper {
    private Mp3ResourceHelper() {
    }
}
